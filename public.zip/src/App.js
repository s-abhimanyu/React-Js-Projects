import React, { createContext, useState } from "react";
import { Routes, Route, useActionData } from "react-router-dom";
import StopWatch from "./Components/StopWatch/StopWatch";
import Header from "./Components/Header/Header";
import Calculator from "./Components/Calculator/Calculator";
import Ledger from "./Components/Ledger/Ledger";
import ToDoTask from "./Components/ToDoTask/ToDoTask"
import AddingDeleting from "./Components/Adding-Deleting/AddingDeleting";
import ProductsPage from "./Components/ShoppindCart/ProductsPage";
import Billing from "./Components/ShoppindCart/Billing";
import Cart from "./Components/ShoppindCart/Cart";
import ShoppingCart from "./Components/ShoppindCart/ShoppingCart";

export const CartContext = createContext();

function App() {

  const [cart, setCart] = useState([]);

  return (

    <CartContext.Provider value={{cart,setCart}}>
      <Header />
      <Routes>
        <Route path='StopWatch' element={<StopWatch />}></Route>
        <Route path='Calculator' element={<Calculator />}></Route>
        <Route path='Ledger' element={<Ledger />}></Route>
        <Route path='ToDoTask' element={<ToDoTask />}></Route>
        <Route path='AddingDeleting' element={<AddingDeleting />}></Route>
        <Route path='Products' element={<ProductsPage />}></Route>
        <Route path='Cart' element={<Cart />}></Route>
        <Route path='Billing' element={<Billing />}></Route>
        <Route path='ShoppingCart' element={<ShoppingCart />}></Route>
      </Routes>
    </CartContext.Provider>


  )
}

export default App;