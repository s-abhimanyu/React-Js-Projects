import React, { useState } from 'react'

function ToDoTask() {
    const [task,setTask] = useState (["Dancing"]);
    const [input1,setInput1] = useState ('');
    const [newtask,setNewTask] = useState ('');


    function HandleInput (event) {
        setInput1(event.target.value)
    }

    function AddTask () {
        const string = parseFloat(input1)
        if (!isNaN(string)){
            alert('Enter only string')
        }
        else {
            setTask([...task,input1])
            setInput1("")
        }
    }

    function Deleteask (index) {
        setTask(task.filter((_,i) => i !== index))
    }

    function Editme (index) {
        const editedtask = [...task]
        editedtask[index] = newtask;
        setTask(editedtask);
    }

    function HandleInput1 (event) {
        setNewTask(event.target.value)
    }
  return (
    <div>
      <input onChange={HandleInput} value={input1}/> 
      <button onClick={AddTask}>Add Task !!</button>
      <h1>Edit Here :</h1>
      <input onChange={HandleInput1} value={newtask}/> 
      <h3>Tasks : {task.map((t,index) => <li>{t} 
        <button onClick={() => Deleteask(index)}>Delete Me !!</button>
        <button onClick={() => Editme(index)}>Update Me !!</button>
        </li>)}</h3>
    </div>
  )
}

export default ToDoTask
