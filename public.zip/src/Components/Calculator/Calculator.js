import React, { useState } from 'react'

function Calculator() {

    const [input,setInput] = useState ('');
    const [result, setResult] = useState ('');

    function HandleClick (value) {
        setInput(input + value)
    }

    function HandleCalculate () {
        try {
            let calc = eval(input);
            setInput(calc);
            setResult(calc);
        }
        catch {
            setResult('Error Check Input')
        }
    }   

    function HandleBackSpace () {
        setInput(input.slice(0,-1))
    }

    function HandleClear () {
        setInput('')
        setResult('')
    }
  return (
    <div className='ms-4 mt-4'>
        <h1>Input : {input}</h1>
        <h1> = {result}</h1>
      <button onClick={() => HandleClick ('1')}>1</button>
      <button onClick={() => HandleClick ('2')}>2</button>
      <button onClick={() => HandleClick ('3')}>3</button>
      <button onClick={() => HandleClick ('4')}>4</button>
      <button onClick={() => HandleClick ('5')}>5</button>
      <button onClick={() => HandleClick ('6')}>6</button>
      <button onClick={() => HandleClick ('7')}>7</button>
      <button onClick={() => HandleClick ('8')}>8</button>
      <button onClick={() => HandleClick ('9')}>9</button>
      <button onClick={() => HandleClick ('0')}>0</button> 

      <button onClick={() => HandleClick ('+')}>+</button> 
      <button onClick={() => HandleClick ('-')}>-</button> 
      <button onClick={() => HandleClick ('*')}>*</button> 
      <button onClick={() => HandleClick ('/')}>/</button> 

      <button onClick={HandleClear}>C</button> 
      <button onClick={HandleCalculate}>=</button> 
      <button onClick={HandleBackSpace}>--</button> 

     
    </div>
  )
}

export default Calculator
