import React, { useState } from 'react'
import './AddDel.css'

function AddingDeleting() {
    const [fruits,setFruits] = useState (["Mango" , "Grapes" , "Kiwi" , "Gova" , "Melons"]);
    const [array,setArray] = useState ([]);
    const [value1,setValue1] = useState('');
    const [value2,setValue2] = useState ('');

    function Add () {
        if ( value1 === '') {
            alert('PLease Select a Value')
        }
        else {
            const add = fruits.indexOf(value1)
            fruits.splice(add,1)
            setArray([...array,value1])
            setValue1('')
        }
    }

    function Remove () {
        if(value2 === ''){
            alert('PLease Select a Value')
        }
        else {
            const rem = array.indexOf(value2);
            array.splice(rem,1);
            setFruits([...fruits,value2])
            setValue2('')
        }
    }

    function HandleList1 (index) {
        setValue1(index)
    }

    function HandleList2 (index) {
        setValue2(index)
    }
  return (
    <div className='flex'>   
        <h1>{fruits.map((i) => <li className= {value1 === i ? 'Selected1' : 'style' } key={i} onClick={() => HandleList1(i)} >{i}</li>)}</h1>
        <button className='btn btn-info ms-2 mt-2' onClick={Add}>Add</button>
        <button className='btn btn-info ms-2 mt-2' onClick={Remove}>Rem</button>
        <h1>{array.map((i) => <li className={value2 === i ? 'Selected2' : 'style'}key={i} onClick={() => HandleList2 (i)} >{i}</li>)}</h1>
    </div>
  )
}

export default AddingDeleting
