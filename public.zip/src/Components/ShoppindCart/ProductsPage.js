import React, { useContext, useState } from 'react'
import { CartContext } from '../../App'

function ProductsPage() {
  const [products] = useState([
    {
        id: 1,
        name: "Gt",
        model: 650,
        price: 300,
        quantity : 0,
    },
    {
        id: 2,
        name: "Yamaha Rx",
        model: 100,
        price: 8000,
        quantity : 0,
    },
    {
        id: 3,
        name: "Royal Field Hunter",
        model: 350,
        price : 9000,
        quantity : 0,
    }
])

  const {cart,setCart} = useContext(CartContext);

  function HandleAddItems (c) {
    const existingItem = cart.find((i) => i.id === c.id)
    if (existingItem) {
      setCart(cart.map((i) => i.id === c.id ? {...i , quantity : i.quantity + 1}: i))
    }
    else {
      setCart([...cart, {...c , quantity : 1}])
    }
  }

  

  return (
    <div>
      <h1>Product Page</h1>
      <h3>{products.map((i) => <li key={i.id}> {i.name} {i.model} <i class="fa-solid fa-rupee-sign"></i> {i.price} 
      <button onClick={() => HandleAddItems (i)}>Add Item !!</button>
      </li>)}</h3>
    </div>
  )
}

export default ProductsPage
