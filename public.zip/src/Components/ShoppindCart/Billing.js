import React, { useContext } from 'react'
import { CartContext } from '../../App'

function Billing() {
    const {cart} = useContext(CartContext);
    const TotalPrice =  cart.reduce((a,b) => a + b.price * b.quantity , 0)
  return (
    <div>
        <h1>Biling Page</h1>
        <h2>Total Price : {TotalPrice}</h2>
    </div>
  )
}

export default Billing
