import React, { useContext } from 'react'
import { CartContext } from '../../App'

function Cart() {
    const {cart,setCart} = useContext(CartContext);

    function HandleDelete (index) {
        setCart(cart.filter((_,i) => i !== index ))
    }


    function AddQuantity (c) {
        setCart(cart.map((i) => i.id === c.id ? {...i, quantity: i.quantity+1} : i))
    }

    function DecQuantity (c) {
        setCart(cart.map((i) => i.id === c.id && i.quantity > 1 ? {...i , quantity: i.quantity-1} : i))
    }
  return (
    <div>
            <h1>Cart Page</h1>
            <h3>{cart.map((i,index) => <li key={i.id}> {i.name} {i.model} <i class="fa-solid fa-rupee-sign"></i> {i.price}  Quantity : {i.quantity} 
            <button onClick={() => AddQuantity (i)}>+</button>
            <button onClick={() => DecQuantity (i)}>-</button>
            <button onClick={() => HandleDelete (index)}>Delete Item !! </button>
            </li> )}</h3>
    </div>
  )
}

export default Cart
