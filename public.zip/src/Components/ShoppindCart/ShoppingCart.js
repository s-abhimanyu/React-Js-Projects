import React, { useState } from 'react'

function ShoppingCart() {
    const [products] = useState([
        {
            id: 1,
            name: "Gt",
            model: 650,
            price: 300,
            quantity: 0,
        },
        {
            id: 2,
            name: "Yamaha Rx",
            model: 100,
            price: 8000,
            quantity: 0,
        },
        {
            id: 3,
            name: "Royal Field Hunter",
            model: 350,
            price: 9000,
            quantity: 0,
        }
    ])

    const [cart, setCart] = useState([]);


    function AddItems(c) {
        const existingitem = cart.find((i) => i.id === c.id)
        if (existingitem) {
            setCart(cart.map((i) => i.id === c.id ? { ...i, quantity: i.quantity + 1 } : i))
        }
        else {
            setCart([...cart,{...c , quantity : 1}])
        }
    }

    function DelItems(c) {
        setCart(cart.filter((_, i) => i !== c))
    }

    function IncreaseQuantity (c) {
        setCart(cart.map((i) => i.id === c.id ? {...i, quantity : i.quantity +1 }: i))
    }

    function DecreaseQuantity (c) {
        setCart(cart.map((i) => i.id === c.id && i.quantity > 1 ? {...i, quantity :  i.quantity -1 } : i))
    }

    const TotalPrice = cart.reduce ((a,b) => a + b.price * b.quantity,0)
    const CartQuantiy = cart.reduce((a,b) => a + b.quantity, 0)
    const CartLength = cart.length;
    return (
        <div>
            <h1>ShoppingCart</h1>
            <h3>{products.map((i) => <li key={i.id}> {i.name} {i.model} <i class="fa-solid fa-rupee-sign"></i>  {i.price}
                <button onClick={() => AddItems(i)}>Add Item !!</button>
            </li>)}</h3>

            <h3>{cart.map((i, index) => <li key={i.id}> {i.name} {i.model} <i class="fa-solid fa-rupee-sign"></i>  {i.price} Quantity : {i.quantity}
                <button onClick={() => IncreaseQuantity(i)}>+</button>
                <button onClick={() => DecreaseQuantity(i)}>-</button>
                <button onClick={() => DelItems(index)}>Delete Item !!</button>

            </li>)}</h3>

            <h4>TotalPrice : {TotalPrice} </h4>
            <h4><i class="fa-solid fa-cart-shopping"></i>: {CartLength} </h4>
            <h4>Total Items in Cart : {CartQuantiy} </h4>
        </div>
    )
}

export default ShoppingCart
