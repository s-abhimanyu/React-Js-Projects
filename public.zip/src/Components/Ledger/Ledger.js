import React, { useState } from 'react'


function Ledger() {
    const [income, setIncome] = useState([]);
    const [expense, setExpense] = useState([]);

    const [input1, setInput1] = useState('');
    const [input2, setInput2] = useState('');

    function HandleIncome(event) {
        setInput1(event.target.value)
    }

    function HandleExpense(event) {
        setInput2(event.target.value)
    }

    function AddIncome() {
        const inputparse = parseFloat(input1);
        if (isNaN(inputparse)) {
            alert('Enter Only Number')
        }
        else {
            setIncome([...income, inputparse])
            setInput1("")
        }
    }

    function AddExpense() {
        const inputparse = parseFloat(input2);
        if (isNaN(inputparse)){
            alert('Enter only Number');
        }
        else {
            setExpense([...expense, inputparse])
            setInput2("")
        }
    }

    const TotalIncome = income.reduce((a, b) => a + b, 0)
    const TotalExpense = expense.reduce((a, b) => a + b, 0)
    const Total = TotalIncome - TotalExpense;


    return (
        <div>
            <h3>Enter Income : <input className='ms-2 mb-2 mt-2' value={input1} onChange={HandleIncome} /> <button onClick={AddIncome}>Add Income</button></h3>
            <h3>Enter Expense : <input className='ms-1'value={input2} onChange={HandleExpense} />  <button onClick={AddExpense}>Add Expense</button> </h3>

            <h3>Income : </h3>
            <h4>{income.map((i) => <li>{i}</li>)}</h4>

            <h3>Expense : </h3>
            <h4>{expense.map((e) => <li>{e}</li>)}</h4>

            <h1>Total Income : {TotalIncome}</h1>
            <h1>Total Expense : {TotalExpense}</h1>
            <h1>Total Left : {Total}</h1>
        </div>
    )
}

export default Ledger
