import React, { useContext } from 'react'
import { NavLink } from 'react-router-dom'
import { CartContext } from '../../App'

function Header() {
    const {cart} = useContext(CartContext);
    const CartItems = cart.reduce((a,b) => a + b.quantity ,0)
    return (
        <div>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='StopWatch'> StopWatch </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='Calculator'> Calculator </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='Ledger'> Ledger </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='ToDoTask'> ToDoTask </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='AddingDeleting'> AddingDeleting </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='Products'> ProductsPage </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='Cart'> CartPage <i class="fa-solid fa-cart-shopping"></i> {CartItems}</NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='Billing'> BillingPage </NavLink>
            </button>
            <button className='btn btn-info ms-2 mt-2 '> 
                <NavLink to='ShoppingCart'> ShoppindCart </NavLink>
            </button>
        </div>
    )
}

export default Header
