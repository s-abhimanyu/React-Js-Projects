import React, { useEffect, useState } from 'react'

function StopWatch() {
    const [time,setTime] = useState ( {
        hours : 0,
        minutes : 0,
        seconds : 0,
        milliseconds : 0
    });

    const [running, setRunning] = useState (false);

    useEffect(()=> {
        let timer ; 
        if (running) {
            timer = setInterval(() => {
                setTime((prevTime) => {
                    let {hours , minutes , seconds , milliseconds} = prevTime;

                    milliseconds++ ;

                    if (milliseconds === 100){
                        milliseconds = 0 ;
                        seconds++;
                    }

                    if (seconds === 60) {
                        seconds = 0 ;
                        minutes++;
                    }

                    if (minutes === 60) {
                        minutes = 0;
                        hours ++ ; 
                    }

                    return {hours , minutes , seconds , milliseconds}
                })
            },10)
        }
        return () => clearInterval(timer)
    },[running])

    function HandleStart () {
        // setRunning(true);
        setRunning(!running);
    }

    function HandlePause () {
        setRunning(false);
    }

    function HandleReset () {
        setRunning(false);
        setTime({hours :0 , minutes: 0, seconds : 0, milliseconds : 0});
    }

    function PadZero (number) {
        return (number < 10 ? '0' : '') + number;
    }
  return (
    <div>
      <h1 className='ms-4 mt-4'>{PadZero(time.hours)}:{PadZero(time.minutes)}:{PadZero(time.seconds)}:{PadZero(time.milliseconds)} </h1>
      <button className='ms-4' onClick={HandleStart}> {!running ? "Start" : "Pause"}</button>
      {/* <button className='ms-4' onClick={HandlePause}> Pause</button> */}
      <button className='ms-4' onClick={HandleReset}> Reset</button>
    </div>
  )
}

export default StopWatch
