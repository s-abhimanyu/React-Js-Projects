import React, { useEffect, useState } from 'react'
import styles from './SelfPractice.module.css'

const SelfPractice = () => {


   return (
      // <div className={`btn btn-primary ${styles.body} ${styles.hero}`}>
      //    <marquee scrollamount="10">
      //     SelfPractice</marquee>
      // </div>
      <div>

      </div>
   )
}

export default SelfPractice
