import React,{useState} from "react";
function Arrays () {

    const [fruits,setFruits] = useState (["Apple","Banana","Grapes"]);

    function HandleAddFruits () {
        const AddItems = document.getElementById("fruitsInput").value;
        document.getElementById("fruitsInput").value= '';

        setFruits([...fruits,AddItems])
    }

    function HandleRemoveFruits (index) {
        setFruits (fruits.filter((_,i) => i !== index))
    }

    return (
        <div>
            <h3>List of Fruits </h3>
           <ol>{fruits.map((fruits,index) => <li onClick={() => HandleRemoveFruits(index)} key={index}>{fruits}</li>)} </ol> 
           <input type="text" id="fruitsInput" placeholder="Enter ur Fruit"></input>
           <button onClick={HandleAddFruits}>Add Fruit</button>
        </div>
    ) 

}

export default Arrays;