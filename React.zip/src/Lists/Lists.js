import '../App.css'

function Lists  (props) {
    
    const ItemsList = props.items;
    const Category1 = props.category;


    // const FilterItem = fruits.filter(fruits => fruits.calories < 100 );
    // const ListItems = FilterItem.map ( FilterItem => <li key={FilterItem.id} >  {FilterItem.name} : {FilterItem.calories} </li>)
    
    const ListItems = ItemsList.map( items => <li key={items.id} >  {items.name} : {items.calories} </li>)
    
    return (
        <>
        <h3 className='ms-3'>{Category1}</h3>
        <ol>{ListItems}</ol>
        </>
    )
}

export default Lists ;
// const fruits = [
//                     {id:1 , name: "Apple", calories : 100},
//                     {id:2 , name: "Grapes", calories : 77},
//                     {id:3 , name: "Banana", calories : 34},
//                     {id:4 , name: "Goa", calories : 174},
//                     {id:5 , name: "Kiwi", calories : 32},
// ];