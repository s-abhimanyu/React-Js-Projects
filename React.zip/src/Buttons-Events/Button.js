function Button () {

    const handleButton = (event) => {
            event.target.textContent = "Clicked !!"
            event.target.style.color = "red"
            console.log(event);
            console.log ("U Have Clicked the Button !!")     
        }

    const handleButtonDisappear = (event) => {
            event.target.style.display = "none"
            console.log("Ur Button Has Disappeared !!")
    }

    return (
        <div>
            <button className='ms-2 mb-2 btn btn-primary' onClick={(event) => handleButton(event)}>Click Me !!</button> <br></br>
            <button className='ms-2 mb-2 btn btn-primary' onClick={(event) => handleButtonDisappear(event)}>Disapper Me !!</button>
        </div>
    );
}

export default Button ; 