import React,{useContext} from 'react'
import ComponentD from './ComponentD'
import './Component.css'

import { UserContext } from './ComponentA'


const ComponentC = (props) => {
    const user = useContext(UserContext);
  return (
    <div className='border'>
        <h2>ComponentC</h2>
        <h3>{`You are in C : ${user}`}</h3>
      <ComponentD user= {props.user}/>
    </div>
  )
}

export default ComponentC
