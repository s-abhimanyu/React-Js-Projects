import React from 'react'
import ComponentC from './ComponentC'
import './Component.css'
import { useContext } from 'react'
import { UserContext } from './ComponentA'


const ComponentB = (props) => {
    const username = useContext(UserContext);
  return (
    <div className='border'>
        <h2>ComponentB</h2>
        <h3>{`You are in B : ${username}`}</h3>
      <ComponentC user={props.user}/>
    </div>
  )
}

export default ComponentB
