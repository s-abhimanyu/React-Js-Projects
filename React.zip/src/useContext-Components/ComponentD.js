import React from 'react'
import './Component.css'


const ComponentD = (props) => {
  return (
    <div className='border'>
        <h1>ComponentD</h1>
      <h2>{`Bye : ${props.user}`}</h2>

    </div>
  )
}

export default ComponentD
