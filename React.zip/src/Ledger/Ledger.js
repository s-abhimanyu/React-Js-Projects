import React, { useState } from 'react';

const Ledger = () => {
    const [incomes, setIncomes] = useState([]);
    const [expenses, setExpenses] = useState([]);
    const [incomeInput, setIncomeInput] = useState('');
    const [expenseInput, setExpenseInput] = useState('');

    const handleIncomeChange = (event) => {
        setIncomeInput(event.target.value);
    };

    const handleExpenseChange = (event) => {
        setExpenseInput(event.target.value);
    };

    const handleAddIncome = () => {
        const newIncome = parseFloat(incomeInput);
        if(isNaN(newIncome)){   
            alert("Not a Number , Please Check ur Input !!")
        }
        else{
            setIncomes([...incomes, newIncome]);
        }  
    };

    const handleAddExpense = () => {
        const newExpense = parseFloat(expenseInput);
        if (isNaN(newExpense)){
            alert("Not a Number , Please Check ur Input !!")
        }
        else{
            setExpenses([...expenses, newExpense]);
        }
    };

    const totalIncome = incomes.reduce((acc, curr) => acc + curr, 0);
    const totalExpense = expenses.reduce((acc, curr) => acc + curr, 0);
    const remainingIncome = totalIncome - totalExpense;

    return (
        <div>
            <h1>Enter your Income:</h1>
            <input type="text" value={incomeInput} onChange={handleIncomeChange} />
            <button onClick={handleAddIncome}>Add Income</button>

            <h2>Enter your Expense:</h2>
            <input type="text" value={expenseInput} onChange={handleExpenseChange} />
            <button onClick={handleAddExpense}>Add Expense</button>

            <h3>Incomes:</h3>
            <ol>
                {incomes.map((income, index) => (
                    <li key={index}>{income}</li>
                ))}
            </ol>

            <h3>Expenses:</h3>
            <ol>
                {expenses.map((expense, index) => (
                    <li key={index}>{expense}</li>
                ))}
            </ol>

            <h3>Total Income: {totalIncome}</h3>
            <h3>Total Expense: {totalExpense}</h3>
            <h3>Remaining Income: {remainingIncome}</h3>
        </div>
    );
};

export default Ledger;
