// import React,{useState} from 'react'

// Using Document Write 
// function TrianglePattern() {
//     const [stare, setStare] = useState('')


// function Pattern () {
//     for (let i = 0; i <= stare; i++) {
//         for (let j = 0; j < i; j++) {
//             document.write('*')
//         }
//         document.write("<br>")
//     }
// }

//     function HandleInput(event) {
//         setStare(event.target.value)
//     }

//     return (
//         <div>
//             <input onChange={HandleInput}></input>
//             <button onClick={Pattern}>Print Pattern</button>
//         </div>
//     )
// }
// export default TrianglePattern


// Using Only React 
import React,{useState} from 'react'

function TrianglePattern() {
    const [pattern, setPattern] = useState([]);
    const [inputValue, setInputValue] = useState('');

    function generatePattern() {
        let newPattern = [];
        for (let i = 1; i <= inputValue; i++) {
            newPattern.push('*'.repeat(i));
        }
        setPattern(newPattern);
    }

    function handleInput(event) {
        setInputValue(event.target.value);
    }
    return (
        <div>
            <input type="number" onChange={handleInput} value={inputValue}></input>
            <button onClick={generatePattern}>Print Pattern</button>
            <div>
                {pattern.map((line, index) => (
                    <div key={index}>{line}</div>
                ))}
            </div>
        </div>
    );
    
}

export default TrianglePattern

