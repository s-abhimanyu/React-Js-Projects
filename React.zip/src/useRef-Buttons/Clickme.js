import React,{useEffect, useRef} from 'react'

const Clickme = () => {
    const InputRef1 = useRef(null)
    const InputRef2 = useRef(null)
    const InputRef3= useRef(null)
    // const ref = useRef(0)
    
    useEffect (() => {
        console.log("Component Render ")
    })

    function HandleFunction1 () {
        // ref.current++;
        // console.log(ref.current)
        InputRef1.current.focus();
        InputRef1.current.style.backgroundColor = "Yellow";
        InputRef2.current.style.backgroundColor = "";
        InputRef3.current.style.backgroundColor = "";

    }

    function HandleFunction2 () {
        InputRef2.current.focus();
        InputRef1.current.style.backgroundColor = "";
        InputRef2.current.style.backgroundColor = "Yellow";
        InputRef3.current.style.backgroundColor = "";
    }

    function HandleFunction3 () {
        InputRef3.current.focus();
        InputRef1.current.style.backgroundColor = "";
        InputRef2.current.style.backgroundColor = "";
        InputRef3.current.style.backgroundColor = "Yellow";
    }
    
    
    return (
        <div>
      <button onClick={HandleFunction1}>Click Me !!</button><br/>
      <input ref={InputRef1}></input><br/>

      <button onClick={HandleFunction2}>Click Me !!</button><br/>
      <input ref={InputRef2}></input><br/>

      <button onClick={HandleFunction3}>Click Me !!</button><br/>
      <input ref={InputRef3}></input>
    </div>
  )
}

export default Clickme
