import React,{useEffect,useState}from 'react'
import './Frequency.css'

function FrequencyComponent() {
  const [input, setInput] = useState('');
  const [frequency, setFrequency] = useState({});

  const handleInputChange = (event) => {
    setInput(event.target.value);
  };

  useEffect(() => {
    const freq = {};
    for (let char of input) {
      if (freq[char]) {
        freq[char]++;
      } else {
        freq[char] = 1;
      }
    }
    setFrequency(freq);
  }, [input]);

  return (
    <div>
      <h1>Frequency of Characters</h1>
      <input
        type="text"
        value={input}
        onChange={handleInputChange}
        placeholder="Enter a string of characters"
      />
      <ul>
        {Object.keys(frequency).map(key => (
          <li key={key}>
            {key}: {frequency[key]}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default FrequencyComponent;
