import React , {useState} from 'react'

function UseStateExample () {

    const [name,setName] = useState("Guest");
    const [age,setAge] = useState(0);
    const [isEmployed,IsEmployed] = useState(false);

    const ChangeNameHandler = () => {
        setName("Abhimanyu")
    }

    const ChangeAgeHandler = () => {
        setAge(age + 1)
    }

    const ChangeStatus = () => {
        IsEmployed(!isEmployed);
    }

return (
    <div>
        <p>Name : {name}</p>
        <button className='ms-2 btn btn-primary' onClick={ChangeNameHandler}>Change Name !!</button>

        <p>Age : {age}</p>
        <button className='ms-2 btn btn-primary' onClick={ChangeAgeHandler}>Change Age !!</button>

        <p>IsEmployed :{isEmployed ? "Yes" : "No"}</p>
        <button className='ms-2 btn btn-primary' onClick={ChangeStatus}>Toggele Status !!</button>
    </div>
) ;


}   

export default UseStateExample;