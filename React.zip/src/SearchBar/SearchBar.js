import React, { useState } from 'react'
 
function Searchbar() {
  const [data]=useState(['Home','Mens','Womens','Kids','Footwear','Cart-Page','Wishlist','Well',''])
  const [final,setFinal]=useState('')
  const searchdata=(event)=>{
      const id=event.target.value
      let flag=false
        for(let i of data){
   
            if (id===i.substring(0,id.length)){
                setFinal(i)
                flag=true
            }
            console.log(i.substring(0,id.length))
            console.log(id)
        }
        if(!flag){
            setFinal('Not Found')
        }
  }
 
  return (
    <div>
      <h1 className='ms-2 me-4'>Search : <input className='btn-info' type='text' onChange={searchdata}/> </h1>
      <h2 className='ms-5'>{final}</h2>
    </div>
  )
}
 
export default Searchbar