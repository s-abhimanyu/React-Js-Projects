import React from 'react'
import { NavLink} from 'react-router-dom'
// import { useNavigate } from 'react-router-dom'

function NotFound() {
    // const navigate = useNavigate() ;
    // function HandleNavigate () {
    //     navigate("/")
    // }
  return (
    <div>
      <h1>The Page you are Looking For Is Not Avaiable : GO BACK TO HOME !!</h1>
      {/* <button className='btn btn-primary' onClick={HandleNavigate}>Go Back Home !!</button> */}
       <NavLink className='btn btn-primary ms-2' to='/'>Go Back Home !! </NavLink> 
    </div>
  )
}

export default NotFound
