import React, { useState } from 'react'
import './Calculator.css'

function Calculator() {
    const [input, setInput] = useState('');
    const [result, setResult] = useState('');

    function HandleClick(value) {
        setInput(input + value);
    }

    function HandleClear() {
        setInput('');
        setResult('');
    }

    function HandleCalculate() {
        try {

            let calc = eval(input);
            setResult(calc);
            setInput(calc);

            // let t = calc;
            // setResult((eval(input)));
        }
        catch {
            setResult('Error')
        }
    }

    function HandleBackSpace() {
        setInput(input.slice(0, -1))
    }

    return (

        <div className="calculator">
            <div className="display">
                <div className="input">{input}</div>
                <div className="result">{result}</div>
            </div>
            <div className="buttons">
                <button onClick={() => HandleClick('1')}>1</button>
                <button onClick={() => HandleClick('2')}>2</button>
                <button onClick={() => HandleClick('3')}>3</button>
                <button onClick={() => HandleClick('4')}>4</button>
                <button onClick={() => HandleClick('5')}>5</button>
                <button onClick={() => HandleClick('6')}>6</button>
                <button onClick={() => HandleClick('7')}>7</button>
                <button onClick={() => HandleClick('8')}>8</button>
                <button onClick={() => HandleClick('9')}>9</button>
                <button onClick={() => HandleClick('0')}>0</button>

                <button onClick={() => HandleClick('+')}>+</button>
                <button onClick={() => HandleClick('*')}>*</button>
                <button onClick={() => HandleClick('-')}>-</button>
                <button onClick={() => HandleClick('/')}>/</button>
                <button onClick={() => HandleClick('.')}>.</button>

                <button onClick={HandleBackSpace}>←</button>
                <button onClick={HandleCalculate}>=</button>
                <button onClick={HandleClear}>C</button>
            </div>
        </div>
    )
}

export default Calculator
