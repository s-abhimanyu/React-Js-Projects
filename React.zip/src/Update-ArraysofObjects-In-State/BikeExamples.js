import React,{useState} from 'react'

function BikeExamples() {

    const [bikes,setBikes] = useState([]);
    const [year,setYear] = useState(new Date().getFullYear());
    const [name,setName] = useState('');
    const [model,setModel] = useState('');


    function HandleYearChange (event) {
        setYear(event.target.value)
    }

    function HandleNameChange (event) {
        setModel(event.target.value)
    }

    function HandleModelChange (event) {
        setName(event.target.value)
    }

    function HandleAddBike () {
        const addedBikes = {name : name , model : model , year: year}

        setBikes([...bikes , addedBikes ])
    }

    function HandleRemoveBike (index) {
        setBikes(bikes.filter((_,i) => i !== index))
    }

  return (
    <div>
      <h5>LisT oF Bikes : </h5>
      <ol>{bikes.map((bikes,index)=> <li onClick={() => HandleRemoveBike(index)} key={index}>{bikes.name} {bikes.model} {bikes.year}</li>)}</ol>
      <input type='text' id="BikeName" placeholder='Enter ur Bike Name' onChange={HandleNameChange}/><br/>
      <input type='text' id="BikeModel" placeholder='Enter ur Bike Model'  onChange={HandleYearChange} /><br/>
      <input type='number' id="BikeYear" placeholder='Enter ur Bike Year' onChange={HandleModelChange} /><br/>
      <button onClick={HandleAddBike}>Add Bike !!</button>
    </div>
  )
}

export default BikeExamples
