import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { CartContext } from '../App';
import './Header.css';

function Header() {
    const {cart} = useContext(CartContext);
    const CartsItems = cart.reduce((a,b)=> a + b.quantity , 0 ) ;
    return (
        <nav className="navbar navbar-expand-lg bg-body-tertiary ">
            <div className="container-fluid bg-secondary">
                <NavLink className="navbar-brand nav-link" to="/"> Home </NavLink>

                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <NavLink className="nav-link" to="ComponetsRender"> ComponetsRender</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Card"> Card</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Student"> Student</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Lists"> Lists</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Button"> Button</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="UseState"> UseState</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Counter"> Counter</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="OnChange"> OnChange</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="ColorPicker"> ColorPicker</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="CarsExample"> CarsExample</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Arrays"> Arrays</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="BikeExamples"> BikeExamples</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="ToDoTask"> ToDoTask</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Clock"> Clock</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="ComponentA"> ComponentA</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Stopwatch"> Stopwatch</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="ShoppingCart"> ShoppingCart</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="PasswordChecker"> PasswordChecker</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Ledger"> Ledger</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Clickme"> Clickme</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Calculator"> Calculator</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="ShoppingCartApi"> ShoppingCartApi</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="AddingDeleting"> Adding-Deleting</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="SearchBar"> SearchBar</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Fibo"> Fibo</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="TrainglePattern"> Traingle-Pattern </NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="Palindrome"> Palindrome </NavLink>
                            </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="FrequencyComponent"> Frequency-Component</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="ProductsPage"> ProductsPage</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="CartPage"> CartPage <i class="fa-solid fa-cart-shopping"></i> {CartsItems}</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="BillPage"> BillPage</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " to="SelfPractice"> SelfPractice</NavLink>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    );
}

export default Header;
