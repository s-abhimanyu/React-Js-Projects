import React, { useContext } from 'react'
import { CartContext } from '../App'

function CartsPage() {
    const {cart,setCart} = useContext(CartContext);
    function HandleDeleteItems (index) {
        setCart(cart.filter((_,i) => i !== index))
    }

    function HandleAddQuantity (c) {
        setCart (cart.map((i) => i.id === c ?  {...i, quantity : i.quantity + 1 } : i ))
    }

    function HandleDecreaseQuantity (c) {
        setCart (cart.map((i) => i.id === c && i.quantity > 1 ? {...i, quantity: i.quantity -1 }: i))
    }
   
  return (
    <div>
        <ol>{cart.map((cart,index) => <li key={cart.id}>{cart.name} {cart.model} ${cart.price} Quantity :{cart.quantity}
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleAddQuantity(cart.id)}>+</button>
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleDecreaseQuantity(cart.id)}>-</button>
            <button onClick={() => HandleDeleteItems (index)} className='ms-2 mt-2 btn btn-primary'>Delete Me !!</button></li>)}
            </ol>
    </div>
  )
}

export default CartsPage
