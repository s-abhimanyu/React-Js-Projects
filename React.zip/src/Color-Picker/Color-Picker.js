import { useState } from "react";

function ColorPicker () {
    const [color,setColor] = useState ("#ffffff");

    function HandleColorChange (event){
        setColor(event.target.value);
    }
return (
    <div>
        <label>Ur Color : 
        <p style={{backgroundColor : color}}>{color}</p>
        </label>
        <br/>
        <label> Pick A Color : <br/>
        <input type='color' onChange={HandleColorChange}></input>
        </label>
    </div>
) ;
}

export default ColorPicker;