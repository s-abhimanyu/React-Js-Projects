import React , {useState} from 'react'

function OnChange () {
    const [name,setName] = useState("");
    const [quan,setQuan] = useState(1);
    const [comment,setCommnet] = useState("");
    const [select,setSelect] = useState("");
    const [status,setStatus] = useState();



    function HandleNameChange (event) {
        setName(event.target.value); 
    }

    function HandleNumberChange (event) {
        setQuan(event.target.value); 
    }

    function HandleTextArea (event) {
        setCommnet(event.target.value); 
    }

    function HandleSelect (event) {
        setSelect(event.target.value)
    }

    function Status (event) {
        setStatus(event.target.value)
    }



    return (
        <div>
            <br/>
            <input type='name' onChange={HandleNameChange}/>
            <p>Name : {name} </p>
            <br/>
            <input type='number' onChange={HandleNumberChange}/>
            <p>Quantity : {quan} </p>
            <br/>
            <textarea onChange={HandleTextArea} />
            <p>Comment : {comment}</p>
            <br />
            <select onChange={HandleSelect}> 
            <option value=''>select ur method</option>
            <option value='Visa'>Visa </option>
            <option value='MasterCard'>MasterCard </option>
            </select>
            <p>U have Selected : {select}</p>
            <br/>
            <input type='radio' value='PickUp' checked={status === 'PickUp'} onChange={Status}></input> &nbsp;
            <label >PickUp</label>
            <br/>
            <input type='radio' value='Delivery' checked={status === 'Delivery'} onChange= {Status} ></input> &nbsp;
            <label >Delivery</label>
            <br/>
            <p>Status : {status}</p>

        </div>
    );
}

export default OnChange ; 