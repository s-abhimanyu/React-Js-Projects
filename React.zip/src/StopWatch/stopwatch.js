import React, { useEffect, useState } from 'react';

// const Stopwatch = () => {

//     const [time, setTime] = useState({
//         hours: 0,
//         minutes: 0,
//         seconds: 0,
//         milliseconds: 0,
//     });
//     const [running, setRunning] = useState(false);

//     useEffect(() => {
//         let timer;
//         if (running) {
//             timer = setInterval(() => {
//                 setTime((prevTime) => {
//                     let { hours, minutes, seconds, milliseconds } = prevTime;

//                     milliseconds++;

//                     if (milliseconds === 100) {
//                         milliseconds = 0;
//                         seconds++;
//                     }

//                     if (seconds === 60) {
//                         seconds = 0;
//                         minutes++;
//                     }

//                     if (minutes === 60) {
//                         minutes = 0;
//                         hours++;
//                     }
//                     return { hours, minutes, seconds, milliseconds };
//                 });
//             }, 10);
//         }
//         return () => clearInterval(timer);
//     }, [running]);

//     const startPause = () => {
//         setRunning(!running);
//     };

//     const stop = () => {
//         setTime({ hours: "0", minutes: "0", seconds: "0", milliseconds: "0" });
//         setRunning(false);
//     };

//     return (
//         <div className="container">
//             <div class="box">
//                 <div class="hours">
//                     {time.hours < 10 ? "0" + time.hours : time.hours}
//                 </div>
//                 <span>:</span>
//                 <div class="minutes">
//                     {time.minutes < 10 ? "0" + time.minutes : time.minutes}
//                 </div>
//                 <span>:</span>
//                 <div class="seconds">
//                     {time.seconds < 10 ? "0" + time.seconds : time.seconds}
//                 </div>
//                 <span>:</span>
//                 <div class="milliseconds">
//                     {time.milliseconds < 10
//                         ? "0" + time.milliseconds
//                         : time.milliseconds}
//                 </div>
//             </div>
//             <div class="box">
//                 <button
//                     onClick={startPause}
//                     className={running ? "pause button" : "play button"}
//                 >
//                     {running ? "Pause" : "Start"}
//                 </button>
//                 <button onClick={stop} className="stop button">
//                     Stop
//                 </button>
//             </div>
//         </div>
//     );
// }
// export default Stopwatch;

const StopWatch = () => {
    const [time, setTime] = useState({
       hours: 0,
       minutes: 0,
       seconds: 0,
       milliseconds: 0,
    });
 
    const [running, setRunning] = useState(false);
 
    useEffect(() => {
       let timer;
       if (running) {
 
          timer = setInterval(() => {
             setTime((prevTime) => {
                let { hours, minutes, seconds, milliseconds } = prevTime;
 
                milliseconds++;
 
                if (milliseconds === 100) {
                   milliseconds = 0;
                   seconds++;
                }
 
                if (seconds === 60) {
                   seconds = 0;
                   minutes++;
                }
 
                if (minutes === 60) {
                   minutes = 0;
                   hours++;
                }
 
                return { hours, minutes, seconds, milliseconds };
             });
          }, 10);
       }
       return () => clearInterval(timer);
    }, [running])
 
    function HandleStart() {
       setRunning(!running);
    }
 
    function HandlePause() {
       setRunning(false);
    }
 
    function HandleReset() {
       setRunning(false);
       setTime({ hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
    }
 
    function PadZero(number) {
       return (number < 10 ? "0" : " ") + number;
    }
    return (
       <div>
          <h1>{PadZero(time.hours)}:{PadZero(time.minutes)}:{PadZero(time.seconds)}:{PadZero(time.milliseconds)}</h1>
          <button onClick={HandleStart}>{!running ? "Start" : "Pause"}</button>
          {/* <button onClick={HandlePause}>Pause</button> */}
          <button onClick={HandleReset}>Reset</button>
       </div>
    )
 }
 
 export default StopWatch;
