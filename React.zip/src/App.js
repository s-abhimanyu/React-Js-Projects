import React, { createContext, useState } from 'react';
import Card from './Cards/Card';
import Student from './Student/Student';
import ConditionalRender from './Conditional-Render/Conditonal-Render';
import Lists from './Lists/Lists';
import Button from './Buttons-Events/Button';
import UseState from './useState-Counter/useState';
import Counter from './useState-Counter/Counter';
import OnChange from './Onchange/Onchange';
import ColorPicker from './Color-Picker/Color-Picker';
import CarsExample from './Update-Objects-In-State/CarsExample';
import Arrays from './Update-Arrays-In-State/FruitsExample';
import BikeExamples from './Update-ArraysofObjects-In-State/BikeExamples';
import ToDoTask from './To-Do-Tasks/ToDoTask';
import Clock from './useEffect-Clock/Clock';
import ComponentA from './useContext-Components/ComponentA';
import Clickme from './useRef-Buttons/Clickme';
import Stopwatch from './StopWatch/stopwatch';
import ShoppingCart from './ShoppingCart/ShoppingCart';
import PasswordChecker from './PasswordChecker/PasswordChecker';
import Ledger from './Ledger/Ledger';
import Header from './Header/Header';
import Home from './Home/Home';
import NotFound from './NotFound/NotFound';
import Calculator from './Calculator/Calculator';
import ShoppingCartApi from './ShoppingCart/ShoppingCartApi';
import AddingDeleting from './Adding-Deleting/Adding-Deleting';
import Searchbar from './SearchBar/SearchBar';
import Fibo from './Fibo/Fibo';

import ProductsPage from './ProductsPage/ProductsPage';
import CartsPage from './CartsPage/CartsPage';
import BillPage from './BillPage/BillPage';

import FrequencyComponent from './Frequency-Component/FrequencyComponent';
import TrianglePattern from './Triangle-Pattern/TrianglePattern';
import PalindromeChecker from './Palindrome/Palindrome';
import SelfPractice from './SelfPractice/SelfPractice';

import { Route, Routes } from 'react-router-dom';


import './App.css'

export const CartContext = createContext();

function App() {
  const fruits = [
    { id: 1, name: "Apple", calories: 100 },
    { id: 2, name: "Grapes", calories: 77 },
    { id: 3, name: "Banana", calories: 34 },
    { id: 4, name: "Goa", calories: 174 },
    { id: 5, name: "Kiwi", calories: 32 },
  ];

  const vegetable = [
    { id: 6, name: "Brinjal", calories: 100 },
    { id: 7, name: "Leafy", calories: 277 },
    { id: 8, name: "Beans", calories: 534 },
    { id: 9, name: "Chicken", calories: 9174 },
    { id: 10, name: "Mutton", calories: 832 },
  ];

  const [cart,setCart] = useState([]);

  return (
    <CartContext.Provider value = {{cart,setCart}}>
    <div >
      {/* ==================================================================================================== */}
      <Header />
      {/* ==================================================================================================== */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="ComponetsRender" element={<ConditionalRender isLoggedin={true} username="Abhimanyu" />} />
        <Route path="Card" element={<Card />} />
        <Route path="Student" element={<Student name="Abhi" age={30} IsStudent={true} />} />
        <Route path="Lists" element={fruits.length > 0 && <Lists items={[...fruits, ...vegetable]} category="Fruits" />} />
        <Route path="Button" element={<Button />} />
        <Route path="UseState" element={<UseState />} />
        <Route path="Counter" element={<Counter />} />
        <Route path="OnChange" element={<OnChange />} />
        <Route path="ColorPicker" element={<ColorPicker />} />
        <Route path="CarsExample" element={<CarsExample />} />
        <Route path="Arrays" element={<Arrays />} />
        <Route path="BikeExamples" element={<BikeExamples />} />
        <Route path="ToDoTask" element={<ToDoTask />} />
        <Route path="Clock" element={<Clock />} />
        <Route path="ComponentA" element={<ComponentA />} />
        <Route path="Stopwatch" element={<Stopwatch />} />
        <Route path="ShoppingCart" element={<ShoppingCart />} />
        <Route path="PasswordChecker" element={<PasswordChecker />} />
        <Route path="Ledger" element={<Ledger />} />
        <Route path="Clickme" element={<Clickme />} />
        <Route path="Calculator" element={<Calculator />} />
        {/* ==================================================================================================== */}
        <Route path="ProductsPage" element={<ProductsPage />} />
        <Route path="CartPage" element={<CartsPage />} />
        <Route path="BillPage" element={<BillPage />} />
        {/* ==================================================================================================== */}
        <Route path="ShoppingCartApi" element={<ShoppingCartApi />} />
        <Route path="SelfPractice" element={<SelfPractice />} />
        <Route path="AddingDeleting" element={<AddingDeleting />} />
        <Route path="SearchBar" element={<Searchbar />} />
        <Route path="Fibo" element={<Fibo />} />
        <Route path="FrequencyComponent" element={<FrequencyComponent />} />
        <Route path="TrainglePattern" element={<TrianglePattern />} />
        <Route path="Palindrome" element={<PalindromeChecker />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      {/* ==================================================================================================== */}
    </div>
    </CartContext.Provider>
  )
}

export default App;
