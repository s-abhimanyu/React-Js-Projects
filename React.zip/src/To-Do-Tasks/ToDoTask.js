import React, { useState } from 'react';

function ToDoTask() {
  const [tasks, setTask] = useState(["Washing", "Cooking", "Dancing"]);
  const [newtask, setNewTask] = useState("");
  const [editIndex, setEditIndex] = useState(null);
  const [editTask, setEditTask] = useState("");

  function handleName(event) {
    setNewTask(event.target.value);
  }
  
  const handleEditChange = (event) => {
    setEditTask(event.target.value);
  }

  function handleAddItems() {
    if (newtask.trim() !== "") {
      setTask(t => [...t, newtask]);
      setNewTask("");
    }
  }

  const handleDeleteItems = (index) => {
    setTask(tasks.filter((_, i) => i !== index));
  }

  const handleEditTask = (index) => {
    setEditIndex(index);
    setEditTask(tasks[index]);
  }

  const handleSaveEdit = () => {
    const updatedTasks = [...tasks];
    updatedTasks[editIndex] = editTask;
    setTask(updatedTasks);
    setEditIndex(null);
    setEditTask("");
  }

  // function moveUpTask(index) {
  //   if (index > 0) {
  //     const updatedTasks = [...tasks];
  //     [updatedTasks[index], updatedTasks[index - 1]] = [updatedTasks[index - 1], updatedTasks[index]];
  //     setTask(updatedTasks);
  //   }
  // }

  // function moveDownTask(index) {
  //   if (index < tasks.length - 1) {
  //     const updatedItems = [...tasks];
  //     [updatedItems[index], updatedItems[index + 1]] = [updatedItems[index + 1], updatedItems[index]];
  //     setTask(updatedItems);
  //   }
  // }

  return (
    <div>
      <h1>To Do Lists :</h1>
      <input type='text' id='tasks' placeholder="Enter your Task" value={newtask} onChange={handleName} />
      <button className='btn btn-primary ms-2 mt-2' onClick={handleAddItems}>Add Task !!</button>
      <ol>
        {tasks.map((task, index) =>
          <li key={index}>
            {editIndex === index ? (
              <>
                <input type="text" value={editTask} onChange={handleEditChange} />
                <button className='btn btn-primary ms-2 mt-2' onClick={handleSaveEdit}>Save</button>
              </>) : 
              (
              <>
                {task}
                <button className='btn btn-primary ms-2 mt-2' onClick={() => handleDeleteItems(index)}>Delete Me !!</button>
                <button className='btn btn-primary ms-2 mt-2' onClick={() => handleEditTask(index)}>Edit Task !!</button>
                {/* <button className='btn btn-primary ms-2 mt-2' onClick={() => moveUpTask(index)}>Up Task !!</button> */}
                {/* <button className='btn btn-primary ms-2 mt-2' onClick={() => moveDownTask(index)}>Down Task !!</button> */}
              </>
            )}
          </li>
        )}
      </ol>
    </div>
  );
}

export default ToDoTask;
