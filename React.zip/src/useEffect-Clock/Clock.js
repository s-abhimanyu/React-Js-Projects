import React, { useEffect, useState } from 'react'

const Clock = () => {
    const [time,setTime] = useState (new Date())

    useEffect (() => {
        const IntervalId = setInterval (() => {
            setTime(new Date())
        },1000)

        return () => {
            clearInterval(IntervalId)
        }
    },[])

    function format () {
        let hours = time.getHours();
        const minutes = time.getMinutes();
        const seconds = time.getSeconds();
        const meridian = hours >= 12 ? "PM" : "AM"

        hours = hours % 12 || 12 ;

        return `${padZero(hours)}:${padZero(minutes)}:${padZero(seconds)}:${padZero(meridian)}`
    }

    function padZero (number) {
        return (number < 10 ? "0" : "") + number ;
    }


  return (
    <div>
      <h1>{format()}</h1>
    </div>
  )
}

export default Clock
