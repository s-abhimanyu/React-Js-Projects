import React,{useState} from 'react'

function CarsExample() {
    const [cars,setCars] = useState ({name : "Suzuki",year : 2024, model : "zxi++"},);

    function HandleName (event) {
        setCars({...cars,name : event.target.value})
    }

    function HandleYear (event) {
        setCars({...cars , year : event.target.value})
    }

    function Handlemodel (event) {
        setCars({...cars ,model : event.target.value})
    }


  return (
    <div>
      <p>Ur Favorite Car : {cars.name} {cars.year} {cars.model}</p>
      <input type='text' value={cars.name} onChange={HandleName}></input><br/>
      <input type='number' value={cars.year} onChange={HandleYear}></input><br/>
      <input type='text'value={cars.model} onChange={Handlemodel}></input><br/>
    </div>
  )
}

export default CarsExample
