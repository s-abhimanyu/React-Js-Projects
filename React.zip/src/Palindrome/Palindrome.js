
import React, { useState } from 'react';


function PalindromeChecker() {

    const [input, setInput] = useState('');
    const [isPalindrome, setIsPalindrome] = useState(null);

    const handleInputChange = (event) => {
        const value = event.target.value;
        setInput(value);
        checkPalindrome(value);
    };

    const checkPalindrome = (str) => {
        const cleanedStr = str.replace(/[^A-Za-z0-9]/g, '').toLowerCase();
        const reversedStr = cleanedStr.split('').reverse().join('');
        setIsPalindrome(cleanedStr === reversedStr);
    };

    return (
        <div>
            <h1>Palindrome Checker</h1>
            <input
                type="text"
                value={input}
                onChange={handleInputChange}
                placeholder="Enter a string"
            />
            {isPalindrome !== null && (
                <div>
                    {isPalindrome ? (
                        <p>"{input}" is a palindrome!</p>
                    ) : (
                        <p>"{input}" is not a palindrome.</p>
                    )}
                </div>
            )}
        </div>
    );
}

export default PalindromeChecker;
