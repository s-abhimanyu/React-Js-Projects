import React ,{useContext, useState} from 'react'
import { CartContext } from '../App'

function ProductsPage() {
    const {cart,setCart} = useContext(CartContext);
    const [products] = useState([
        {
            id: 1,
            name: "Gt",
            model: 650,
            price: 300,
            quantity: 0,
        },
        {
            id: 2,
            name: "Yamaha Rx",
            model: 100,
            price: 8000,
            quantity: 0,
        },
        {
            id: 3,
            name: "Royal Field Hunter",
            model: 350,
            price: 9000,
            quantity: 0,
        }
    ])

    function HandleAddItems(c) {
        const quantity = cart.find((i) => i.id === c.id)
        if (quantity) {
         setCart(cart.map((i)=> i.id === c.id ? {...i, quantity : i.quantity + 1 } : i))
        }
        else {
         setCart([...cart, {...c , quantity : 1}]);
        }
    }

    return (
        <div>
            <ol>{products.map((products) => <li key={products.id}>{products.name} {products.model} ${products.price}
                <button onClick={() => HandleAddItems(products)} className='ms-2 mt-2 btn btn-primary'>Add Item !!</button></li>)}
            </ol>
        </div>
    )
}

export default ProductsPage
