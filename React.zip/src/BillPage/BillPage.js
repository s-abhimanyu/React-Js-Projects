import React, { useContext } from 'react'
import { CartContext } from '../App'

function BillPage() {
    const {cart} = useContext(CartContext);
    const totalCost = cart.reduce ( (a,b) => a + b.price * b.quantity,0 )
  return (
    <div>
       <h3>Total Price : ${totalCost}</h3>
    </div>
  )
}

export default BillPage
