import React,{useState} from 'react'
import './PasswordChecker.css'

const PasswordChecker = () => {
    const [name,setName] = useState ('');
    const [check,setChecker] = useState('');

    function NameHandler (event) {
        const id = event.target.value;
        if (id.length <= 3 ){
            setName("weak")
            setChecker("red")
        }
        else if (id.length >= 3 && id.length <=5)  {
            setName("medium")
            setChecker("orange")
        }
        else {
            setName("strong")
            setChecker("green")
        }
    }

  return (
    <div>
      <input onChange={NameHandler} ></input>
      <p className={check}> {name}</p>
      </div>
  )
}

export default PasswordChecker;
