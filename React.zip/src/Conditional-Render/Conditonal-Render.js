import PropTypes from 'prop-types'

function ConditionalRender(props) {

    // if (props.isLoggedin) {
    //     return <h2>Hello Welcome {props.username} </h2>
    // }
    // else {
    //     return <h2>PLease Login !!</h2>
    // }

    const WelcomeMsg = <h2> Welcome {props.username} </h2>
    const ErroMsg = <h2> PLease Login !!!</h2>

    return (
        <div>
            
            {props.isLoggedin ?  WelcomeMsg   : ErroMsg }
        </div>
    )

}

ConditionalRender.propTypes = {
    isLoggedin: PropTypes.bool,
    username: PropTypes.string,
}

ConditionalRender.defaultProps = {
    isLoggedin: false,
    username: "Guest",
}

export default ConditionalRender;