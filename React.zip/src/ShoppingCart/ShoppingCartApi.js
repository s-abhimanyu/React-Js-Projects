
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ShoppingCartApi() {

    const [post,setPost] = useState ([]);
    useEffect ( () => {
        axios.get(`http://localhost:9000/posts`)
        .then((post) => {
            setPost(post.data)
        })
        .catch ((err) => {
            console.log("Error" ,err)
        }) 
    },[post])

    function HandlePutCart (j) {
        j.title='hwehakas'
        axios.put(`http://localhost:9000/posts/${j.id}`,j)
    }

    function HandlePostCart () {
        axios.post(`http://localhost:9000/posts/`,{title:'Abhi',body:'lorem5'})
    }
    
    function HandleDeleteCart (j) {
        axios.delete(`http://localhost:9000/posts/${j.id}`,j)
    }


  return (
    <div>
      <h1>Shopping Cart</h1>
        <ol>{post.map((post) => <li>{post.id} {post.body} {post.title} 
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandlePutCart(post)}>Put Cart</button>
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandlePostCart(post)}>POst Cart</button>
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleDeleteCart(post)}>Delete Cart</button>
            </li>)}</ol>
    </div>
  )
}

export default ShoppingCartApi;
