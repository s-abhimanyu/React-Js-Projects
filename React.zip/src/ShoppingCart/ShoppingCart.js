import React, { useState } from 'react'


// const ShoppingCart = () => {
//     const [products] = useState
//         ([
//             {
//                 id: 0,
//                 name: "Bag",
//                 color: "black",
//                 price: 600,
//                 quantity: 0,
//             },
//             {
//                 id: 1,
//                 name: "Laptop",
//                 color: "Green",
//                 price: 708,
//                 quantity: 0,
//             },
//             {
//                 id: 2,
//                 name: "Mouse",
//                 color: "Red",
//                 price: 684,
//                 quantity: 0,
//             }
//         ]
//         )
//         const [cart,setCart] = useState ([]);

//         function HandleAddItems (p) {
//             const existingItem = cart.find( (i)=> i.id === p.id )
//             if (existingItem) {
//                 setCart (cart.map((i) => i.id === p.id ? {...i, quantity : i.quantity +1} : i))
//             }
//             else {
//                 setCart([...cart,{...p , quantity :1 }])
//             }
//         }

//         function HandleDeleteItems (index) {
//             setCart(cart.filter((_,i) => i !== index))
//         }

//         function HandleAddQuantity (c) {
//             setCart (cart.map ((i) => i.id === c ? {...i , quantity  : i.quantity +1 } : i))
//         }

//         function HandleDecreaseQuantity (c) {
//             setCart (cart.map ((i) => i.id === c && i.quantity > 1 ? {...i, quantity : i.quantity -1} : i))
//         }

//         const CartNumber = cart.reduce((a,b)=> a + b.quantity , 0 ) ; 
//         // const CartUnique = cart.length ;
//         const TotalPrice = cart.reduce((a,b) => a + b.price * b.quantity, 0);

//     return (
//         <div>
//             <ol>{products.map((products) => <li key={products.id}>{products.name} {products.color} ${products.price} Quantity: {products.quantity}
//                 <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleAddItems(products)}>Add Cart !! </button></li>)}
//             </ol>

//             <ol>
//                 {cart.map((cart,index) => <li key={cart.id}>{cart.name} {cart.color} ${cart.price} Quantity : {cart.quantity}
//                     <button className='btn btn-primary ms-2 mt-2' onClick={ () => HandleAddQuantity (cart.id)} >+</button>
//                     <button className='btn btn-primary ms-2 mt-2' onClick={ () => HandleDecreaseQuantity (cart.id)}>-</button>
//                     <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleDeleteItems(index)}>Delete Item !!</button>
//                 </li>)}
//             </ol>

//             <h2>Number Of Cart Items : {CartNumber}</h2>  
//             {/* <h2>Number of Unique Items : {CartUnique} </h2> */}
//             <h2>Total Price : $ {TotalPrice}</h2>  
//         </div>
//     )
// }

function ShoppingCart() {
    const [products] = useState([
        {
            id: 1,
            name: "Gt",
            model: 650,
            price: 300,
            quantity : 0,
        },
        {
            id: 2,
            name: "Yamaha Rx",
            model: 100,
            price: 8000,
            quantity : 0,
        },
        {
            id: 3,
            name: "Royal Field Hunter",
            model: 350,
            price : 9000,
            quantity : 0,
        }
    ])

    const [cart, setCart] = useState([])

    function HandleAddItems(c) {
        const quantity = cart.find((i) => i.id === c.id)
        if (quantity) {
         setCart(cart.map((i)=> i.id === c.id ? {...i, quantity : i.quantity + 1 } : i))
        }
        else {
         setCart([...cart, {...c , quantity : 1}]);
        }
    }


    function HandleDeleteItems (index) {
        setCart(cart.filter((_,i) => i !== index))
    }

    function HandleAddQuantity (c) {
        setCart (cart.map((i) => i.id === c ?  {...i, quantity : i.quantity + 1 } : i ))
    }

    function HandleDecreaseQuantity (c) {
        setCart (cart.map((i) => i.id === c && i.quantity > 1 ? {...i, quantity: i.quantity -1 }: i))
    }


    // const CartsUnique = cart.length ; 
    const CartsItems = cart.reduce((a,b)=> a + b.quantity , 0 ) ; 
    const totalCost = cart.reduce ( (a,b) => a + b.price * b.quantity,0 )


    return (
        <div>
            <ol>{products.map((products) => <li key={products.id}>{products.name} {products.model} ${products.price}
                <button onClick={() => HandleAddItems(products)} className='ms-2 mt-2 btn btn-primary'>Add Item !!</button></li>)}
            </ol>

            <ol>{cart.map((cart,index) => <li key={cart.id}>{cart.name} {cart.model} ${cart.price} Quantity :{cart.quantity}
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleAddQuantity(cart.id)}>+</button>
            <button className='btn btn-primary ms-2 mt-2' onClick={() => HandleDecreaseQuantity(cart.id)}>-</button>
            <button onClick={() => HandleDeleteItems (index)} className='ms-2 mt-2 btn btn-primary'>Delete Me !!</button></li>)}
            </ol>

            {/* <h3>Total Cart Items : {CartsItems}</h3> */}
            <h2> <i class="fa-solid fa-cart-shopping"></i> {CartsItems} </h2>
            <h3>Total Price : ${totalCost}</h3>
        </div>
    )
}

export default ShoppingCart

