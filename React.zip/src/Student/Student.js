import PropType from 'prop-types'


function Student(props) {
    return (
        <div className='Student'>
            <p>Name : {props.name}</p>
            <p>Age : {props.age}</p>
            <p>isStudent : {props.IsStudent ? "Yes" : "No"}</p>
        </div>
    );
}
Student.PropsType = {
    name: PropType.string,
    age: PropType.number,
    IsStudent: PropType.bool
}

Student.defaultProps = {
    name : "Guest",
    age : 0,
    IsStudent: false,

}

export default Student;