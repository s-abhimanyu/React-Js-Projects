import React from 'react';
import './Card.css'

function Card() {
    return (
        <section>
            <h1 className='App ms-5'> Cards Componet </h1>
            <div className='card'>
                <img className='card-image' src='https://yt3.ggpht.com/yti/ANjgQV-_VXkqFX3LqpmLU7uOQyAWZcIrLaCN8o818gafjl18e2U=s108-c-k-c0x00ffffff-no-rj' alt='Frog Iamge' style={{ height: 200, width: 200 }}></img>
                <h3>Title </h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, saepe.</p>
            </div>
        </section>
    )
}

export default Card
