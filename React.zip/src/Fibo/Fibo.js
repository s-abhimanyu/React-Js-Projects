import React, { useState } from 'react'

const Fibo = () => {
    const [text, settext] = useState();
    const [list, setlist] = useState([]);

    function Fibo(data) {
        const series = [0, 1];
        for (let i = 2; i < data; i++) {
            series[i] = series[i - 1] + series[i - 2]
        }
        setlist([...list, ...series])
    }

    const handleonchange = (event) => {
        settext(event.target.value)
    }

    return (
        <div className='ms-5'>
            <h1>Fibonacci Series</h1>
            <textarea type="text" value={text} onChange={handleonchange} rows="2" ></textarea>
            <button className=" ms-4 btn btn-primary" onClick={() => Fibo(text)}>Fibonacci</button>
            <h2> {list.map((i) => <span> {i} </span>)} </h2>
        </div>
    )
}
export default Fibo