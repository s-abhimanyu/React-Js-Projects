import React, { useState } from 'react'
import './Adding-Deleting.css'

const AddingDeleting = () => {
    const [rows, setRows] = useState(["Apple", " Banana", "Grapes", " Kiwi", " Jack Fruit"])
    const [newrow, setNewRows] = useState([])
    const [val, setVal] = useState('')
    const [value, setValue] = useState('')

    function HandleAddButton() {
        if (val === '') {
            alert('Please Select a Value ')
        }
        else {
            const add = rows.indexOf(val)
            rows.splice(add, 1)
            setNewRows([...newrow, val])
            setRows([...rows])
        }
        setVal('')
    }

    function HandleDeleteButton() {
        if (value === '') {
            alert('Please Select a Value ')
        }
        else {
            const rem = newrow.indexOf(value)
            newrow.splice(rem, 1)
            setNewRows([...newrow])
            setRows([...rows, value])
        }
        setValue('')
    }

    function Handlelist1(index) {
        setVal(index)
    }

    function Handlelist2 (index) {
        setValue(index)
    }
 return (
        <div className='Flex'>
            <h1>{rows.map((i) => <li key={i} className={val === i ? 'selected1 ' : 'ms-4 me-4 listing' } onClick={() => Handlelist1(i)}>{i}</li>)}</h1>
            <button className="btn ms-2 btn-primary" onClick={HandleAddButton}>Add</button>
            <button className="btn ms-2 btn-primary" onClick={HandleDeleteButton}>Rem</button> 
            <h1>{newrow.map((i) => <li key={i} className={value === i ? 'selected2 ' : 'ms-4 listing'} onClick={() => Handlelist2(i)}>{i}</li>)}</h1>
        </div>
    )
}

export default AddingDeleting
